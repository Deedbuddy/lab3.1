package com.wheredidipark

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions


class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var googleMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var carMarker: Marker? = null

    // Default location (e.g., San Francisco) for initial map view
    private val defaultLocation = LatLng(37.7749, -122.4194)
    private val TAG = "WhereDidIParkApp"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize FusedLocationProviderClient (Location Service - Step 4)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Initialize the Map Fragment
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // Set up the "I'm parked here" button click listener (Step 3)
        val parkButton: Button = findViewById(R.id.parkButton)
        parkButton.setOnClickListener {
            // Add functionality to move the car icon (Step 8)
            updateCarLocation()
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Restore any saved location from SharedPreferences (Bonus Step 10)
        val savedLatLng = restoreLocation()
        if (savedLatLng != null) {
            placeCarMarker(savedLatLng)
            // Animate camera to the saved location
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(savedLatLng, 15f))
        } else {
            // Animate camera to the default location
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 10f))
        }

        // Request the user's permission (Step 5)
        requestLocationPermission()
    }

    // --- Location Permission Handling (Step 5) ---

    private fun requestLocationPermission() {
        when {
            // 1. Permission already granted
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED -> {
                enableMyLocation()
            }
            // 2. Should show rationale dialog
            shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION) -> {
                showRationaleDialog()
            }
            // 3. Request permission
            else -> {
                locationPermissionRequest.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
    }

    // Permission request launcher
    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            enableMyLocation()
        } else {
            Toast.makeText(this, "Location access denied. Cannot use current location.", Toast.LENGTH_LONG).show()
        }
    }

    // Dialog to show rationale for permission request
    private fun showRationaleDialog() {
        AlertDialog.Builder(this)
            .setTitle("Location Permission Needed")
            .setMessage("This app needs location access to pinpoint your current parking spot.")
            .setPositiveButton("OK") { _, _ ->
                // Re-request the permission
                locationPermissionRequest.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            .setNegativeButton("No, Thanks") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }

    // Enables the My Location layer on the map
    @SuppressLint("MissingPermission") // Permission checked in requestLocationPermission
    private fun enableMyLocation() {
        if (::googleMap.isInitialized) {
            googleMap.isMyLocationEnabled = true
        }
    }

    // --- Location and Marker Management (Steps 6, 8) ---

    // Function to get the current location and update the car marker
    private fun updateCarLocation() {
        // Check if permission is granted again before attempting location access
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestLocationPermission()
            return
        }

        // Obtain the user's location (Step 6)
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val currentLatLng = LatLng(location.latitude, location.longitude)

                // Place/move the car marker
                placeCarMarker(currentLatLng)

                // Move the camera to the new location
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 18f))

                // Store the selected location (Bonus Step 9)
                saveLocation(currentLatLng)

                Toast.makeText(this, "Car location updated!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Could not get current location. Try again.", Toast.LENGTH_SHORT).show()
                Log.w(TAG, "Last known location is null.")
            }
        }.addOnFailureListener { e ->
            Log.e(TAG, "Failed to get location: ${e.message}")
            Toast.makeText(this, "Error getting location.", Toast.LENGTH_SHORT).show()
        }
    }

    // Function to place or move the car marker on the map
    private fun placeCarMarker(latLng: LatLng) {
        if (carMarker == null) {
            // Add a car icon to your project (Step 7) and use it here
            val markerOptions = MarkerOptions()
                .position(latLng)
                .title("Last Parked Location")
                .icon(bitmapDescriptorFromVector(this, R.drawable.ic_car)) // Assumes you named the Vector Asset 'ic_car'
            carMarker = googleMap.addMarker(markerOptions)
        } else {
            // Move the existing marker
            carMarker?.position = latLng
        }
    }

    // Converts a vector drawable resource into a BitmapDescriptor for use as a marker icon
    private fun bitmapDescriptorFromVector(context: Context, vectorResId: Int): BitmapDescriptor {
        val vectorDrawable = ContextCompat.getDrawable(context, vectorResId)
        vectorDrawable!!.setBounds(0, 0, vectorDrawable.intrinsicWidth, vectorDrawable.intrinsicHeight)
        val bitmap = Bitmap.createBitmap(
            vectorDrawable.intrinsicWidth,
            vectorDrawable.intrinsicHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        vectorDrawable.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }

    // --- SharedPreferences Functions (Bonus Steps 9 & 10) ---

    // Bonus Step 9: Store the selected location in SharedPreferences
    private fun saveLocation(latLng: LatLng) =
        getPreferences(MODE_PRIVATE)?.edit()?.apply {
            putString("latitude", latLng.latitude.toString())
            putString("longitude", latLng.longitude.toString())
            apply()
            Log.d(TAG, "Location saved: ${latLng.latitude}, ${latLng.longitude}")
        }

    // Bonus Step 10: Restore any saved location from SharedPreferences
    private fun restoreLocation(): LatLng? {
        val sharedPreferences = getPreferences(MODE_PRIVATE) ?: return null

        val latitude = sharedPreferences.getString("latitude", null)?.toDoubleOrNull()
        val longitude = sharedPreferences.getString("longitude", null)?.toDoubleOrNull()

        if (latitude != null && longitude != null) {
            Log.d(TAG, "Location restored: $latitude, $longitude")
            return LatLng(latitude, longitude)
        }
        return null
    }
}