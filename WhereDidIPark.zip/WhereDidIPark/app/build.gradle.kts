// File: app/build.gradle.kts

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    // REMOVED: alias(libs.plugins.kotlin.compose) // Not needed for a View-based map app
}

android {
    namespace = "com.wheredidipark"
    compileSdk = 36 // Keep modern compileSdk

    defaultConfig {
        applicationId = "com.wheredidipark"
        minSdk = 28 // FIXED: Changed from 35 to 24 for broader device support
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8 // FIXED: Changed to 1.8 (or 8)
        targetCompatibility = JavaVersion.VERSION_1_8 // FIXED: Changed to 1.8 (or 8)
    }
    kotlinOptions {
        jvmTarget = "1.8" // FIXED: Changed to 1.8
    }
    // REMOVED: buildFeatures block (compose = true)
}

dependencies {
    // --- Core AndroidX Dependencies (Added explicitly for View-based app) ---
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.10.0")

    // --- Layout and Fragment Dependencies ---
    implementation(libs.androidx.constraintlayout)
    // AppCompat extension for Maps (Needed for SupportMapFragment)
    implementation("androidx.fragment:fragment-ktx:1.6.2")

    // --- Google Services Dependencies (Maps & Location) ---
    implementation("com.google.android.gms:play-services-maps:18.2.0")
    implementation("com.google.android.gms:play-services-location:21.0.1")

    // --- Testing Dependencies ---
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // REMOVED all Compose dependencies (lifecycleRuntimeKtx, activityCompose, composeBom, ui, etc.)
}